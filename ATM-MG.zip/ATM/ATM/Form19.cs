﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace ATM
{
    public partial class Form19 : Form
    {

        public Form19()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Form16 form = new Form16();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Update();
            Form7 form = new Form7();
            form.ShowDialog();  

        }
        
        private void Form19_Load(object sender, EventArgs e)
        {
           
        }
        int id = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (GlobalVariable.acountNo_1 != null)
            {
                id++;
                dataGridView1.Rows.Add(id, GlobalVariable.acountNo_1, "Withdraw", GlobalVariable.withdraw_1, "5/8/2023", GlobalVariable.location_1);
            }

        }
    }
}
