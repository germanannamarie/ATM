﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class Form16 : Form
    {
       
        public Form16()
        {
            InitializeComponent();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            withdraw.Text = GlobalVariable.withdraw_1;
            
            int a = Convert.ToInt32(GlobalVariable.withdraw_1);
            int b = Convert.ToInt32(GlobalVariable.available_Bal);
            int c = b - a;

            acc.Text = GlobalVariable.acountNo_1;
            avail.Text = Convert.ToString(c);

            present.Text = Convert.ToString(c);
            date.Text = "05/08/2023";

            GlobalVariable.current_Bal = Convert.ToString(c);
            GlobalVariable.available_Bal = Convert.ToString(c);
            GlobalVariable.location_1 = "Norzagaray";


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
        int id = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            Form19 form1 = new Form19();
            if (GlobalVariable.acountNo_1 != null)
            {
                id++;
                form1.dataGridView1.Rows.Add(id, acc.Text, "Withdraw", withdraw.Text, "5/8/2023");
            }
            form1.Update();


            this.Hide();
            Form7 form = new Form7();
            form.Show();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
