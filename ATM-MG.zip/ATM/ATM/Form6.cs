﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            textBox1.PasswordChar = '*';
            textBox1.MaxLength = 6;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += 1;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Text += 2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += 3;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += 4;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += 5;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += 6;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += 7;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += 8;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += 9;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text += 0;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        int x = 1;


        private void button11_Click(object sender, EventArgs e)
        {
            string pin = "123456";

            if (textBox1.Text == pin)
            {
                string box_msg = "log In succesfully!";
                MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                this.Hide();
                Form7 form = new Form7();
                form.ShowDialog();
            }

            if (textBox1.Text != pin)
            {
                string box_msg = "Invalid PIN! Please try again \n  Attempts: " + x + " out of 3";
                MessageBox.Show(box_msg, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                x++;
                textBox1.Text = "";

                if (x == 4)
                {
                    string box_msg1 = "Sorry your account is block!";
                    MessageBox.Show(box_msg1, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    this.Hide();
                    Form1 form = new Form1();
                    form.ShowDialog();
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
