﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
        }

        private void Form13_Load(object sender, EventArgs e)
        {

        }

        private void Form13_Load_1(object sender, EventArgs e)
        {
            label7.Text = GlobalVariable.acountNo_1;
            label8.Text = GlobalVariable.available_Bal;
            label9.Text = GlobalVariable.current_Bal;
        }
    }
}
